-- AlterTable
ALTER TABLE "Cliente" ADD COLUMN     "codiceSDI" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "indirizzo" TEXT NOT NULL DEFAULT '';
